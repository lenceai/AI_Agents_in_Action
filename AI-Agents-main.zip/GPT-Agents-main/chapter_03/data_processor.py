import pandas as pd



csv = pd.read_csv('netflix_titles.csv')

print(csv.head())